import { Stack } from 'expo-router';

export default function App() {
  return <Stack initialRouteName="login" />;
}
